var __wpo = {
  "assets": {
    "main": [
      "/favicon.ico",
      "/runtime.66105d2e67cecf6d5119.js",
      "/"
    ],
    "additional": [
      "/npm.react-fast-compare.c498ae394b734ed34d88.chunk.js",
      "/npm.react-helmet.27cecc42a65694f42916.chunk.js",
      "/npm.react-side-effect.11d575f686200d838305.chunk.js",
      "/npm.webpack.4dba867308d911c81c90.chunk.js",
      "/npm.antd.4d52b07e5330cd79527a.chunk.js",
      "/npm.material-ui.b5cb5239184c5526f8c0.chunk.js",
      "/npm.ant-design.0218502dfab56d5cf3b9.chunk.js",
      "/npm.intl.d600b589a6d8230522c5.chunk.js",
      "/main.b60ba9886580da95b02e.chunk.js",
      "/npm.babel.dde3a584b2c04e7759c1.chunk.js",
      "/npm.core-js.6bd96e61b65c546d0cdc.chunk.js",
      "/npm.feathersjs.4ef8743c871b59e57728.chunk.js",
      "/npm.rc-util.2fb6620728e4e988c865.chunk.js",
      "/npm.react-app-polyfill.9025f0d8eaf46c465f9e.chunk.js",
      "/15.052269c6055cb7b72f16.chunk.js",
      "/16.4c720ff9cc912bcc3e3b.chunk.js",
      "/17.75fcf0e0a3c9fbea07a1.chunk.js",
      "/18.eb02b6bd5984a1eaff5d.chunk.js",
      "/19.52233c574e28e9fab017.chunk.js",
      "/20.986f23518cbd8da95c6e.chunk.js",
      "/21.1d8a0fe90c9051afeb23.chunk.js",
      "/22.c07cc6de26aafb11908c.chunk.js",
      "/23.1ca32fb640631f586945.chunk.js",
      "/24.9a7e879e311eec8c3909.chunk.js",
      "/25.40b64c201c3925e55aef.chunk.js",
      "/26.a9d5eb54bd8f8bb7e971.chunk.js",
      "/27.44d1697e78f9430f9597.chunk.js",
      "/28.bf4a5a16d1a06ac0ba95.chunk.js",
      "/29.82d48dcdf98b97342164.chunk.js",
      "/30.6f31cb5d03a5de22f0c6.chunk.js",
      "/31.bf60c722e6b926de88fe.chunk.js",
      "/32.d94a41685154f34ec771.chunk.js",
      "/33.8d706d0547712b4617fa.chunk.js",
      "/34.3fb2f09843a6952799f5.chunk.js",
      "/35.c64ec26b8c18d47f6459.chunk.js",
      "/36.89a3522be118282c11da.chunk.js",
      "/37.6f9b176a3421e302eaca.chunk.js",
      "/38.e7039407436bc19f2e1e.chunk.js",
      "/39.2b697c6d7aeb4f73f4a9.chunk.js",
      "/40.b99752e481cecf87f579.chunk.js",
      "/41.0cf410fee57f643cf1c1.chunk.js",
      "/42.0e9e66baf8e6f82ebf6e.chunk.js",
      "/43.3e9c6b13edca3a1868c7.chunk.js",
      "/44.2516a3c0e7e15719d956.chunk.js",
      "/45.4cf458c298cfebc2c0b8.chunk.js",
      "/46.cc5493e2694e74ad7747.chunk.js",
      "/47.b7a12c8b5f405466ee08.chunk.js",
      "/48.cd06be3c10ca1f6ceaa0.chunk.js",
      "/49.c405b5c69cce9efe901f.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "88fee3859953a1934a1073b5455435d9e4fd9edf": "/favicon.ico",
    "ef041d73d869f38923905aff8c30bf38d1fedbf0": "/npm.react-fast-compare.c498ae394b734ed34d88.chunk.js",
    "dca8269e7995c98e0773efe72b9ce5978497eaa4": "/npm.react-helmet.27cecc42a65694f42916.chunk.js",
    "a516e76a11865e2f04cc47f5ad5e907561e30b69": "/npm.react-side-effect.11d575f686200d838305.chunk.js",
    "606bdc668802534e48ef14560ced198a1772d97a": "/npm.webpack.4dba867308d911c81c90.chunk.js",
    "efbdf3f44d1312bf1906679fdc66d10ee79d0c75": "/npm.antd.4d52b07e5330cd79527a.chunk.js",
    "aca28ecfc75c07e5d9c15c58534247be13f12ef7": "/npm.material-ui.b5cb5239184c5526f8c0.chunk.js",
    "b139f043feda2b784423bd94629466d923826232": "/npm.ant-design.0218502dfab56d5cf3b9.chunk.js",
    "24421e55628b8f84ea6ebe24e32164a4578d473a": "/npm.intl.d600b589a6d8230522c5.chunk.js",
    "cebda58b2fda226f3c17eb61b5577a6cf53f5a97": "/main.b60ba9886580da95b02e.chunk.js",
    "cb03b0107addf8469a3202c06838c7f1dd883926": "/npm.babel.dde3a584b2c04e7759c1.chunk.js",
    "cbcf760993971e95786735c9369fe6c8f87cf4a4": "/npm.core-js.6bd96e61b65c546d0cdc.chunk.js",
    "3b7733296a8101552a508e68a5c1d9b4c4e30275": "/npm.feathersjs.4ef8743c871b59e57728.chunk.js",
    "ae959fce4c9429df886bdf52be3cf542cc139ee7": "/npm.rc-util.2fb6620728e4e988c865.chunk.js",
    "501cdea9fe744cc9a7abc8b65fd81f8e1e9e72a1": "/npm.react-app-polyfill.9025f0d8eaf46c465f9e.chunk.js",
    "eb267082e906ec17fd06d5997c12d111a59fec4e": "/runtime.66105d2e67cecf6d5119.js",
    "9a8c7c167bc90d96c39c80e7eea95567fa5f8124": "/15.052269c6055cb7b72f16.chunk.js",
    "6b387efc9835c448b94964339a6aef79c63eb6bb": "/16.4c720ff9cc912bcc3e3b.chunk.js",
    "d6778e352887be90ef4787d33f54b2bb64725e6d": "/17.75fcf0e0a3c9fbea07a1.chunk.js",
    "5cae1f069e67412af155875c76a98da5176cf1db": "/18.eb02b6bd5984a1eaff5d.chunk.js",
    "c99908ff2be0beb6a0faef87744c52dbafb2001b": "/19.52233c574e28e9fab017.chunk.js",
    "4f43a42094baa133bf46a906dd9b46fca49320ca": "/20.986f23518cbd8da95c6e.chunk.js",
    "23725389acc1071a188b08316d49f380c9eb69aa": "/21.1d8a0fe90c9051afeb23.chunk.js",
    "e7dea1ea52bfe98e275e631c35f1abaac62a590b": "/22.c07cc6de26aafb11908c.chunk.js",
    "0ea923ef957d1c0ebdbea8c5c6bba2bec87be8ad": "/23.1ca32fb640631f586945.chunk.js",
    "aa324960e9c01aa0b15f2e699b25490693f07e16": "/24.9a7e879e311eec8c3909.chunk.js",
    "bfd886d8f28c979ca7364a9a38d42246db6cb00b": "/25.40b64c201c3925e55aef.chunk.js",
    "6532895941a7c53dfb4571e18cc40b09890e2e16": "/26.a9d5eb54bd8f8bb7e971.chunk.js",
    "3ef18001892fd8ddf92053291ea3c3193e272c5e": "/27.44d1697e78f9430f9597.chunk.js",
    "c1214a3f4912da38b190d09fa680237aacf00183": "/28.bf4a5a16d1a06ac0ba95.chunk.js",
    "6d846a82ac35deba904cc16fe7a872c8af308a79": "/29.82d48dcdf98b97342164.chunk.js",
    "ccfed41cbb3d60a7e08d12ef2ac4002f63fd85de": "/30.6f31cb5d03a5de22f0c6.chunk.js",
    "8a67f461e0249eadd035c2ca0f997a740b556236": "/31.bf60c722e6b926de88fe.chunk.js",
    "75cf3b010315ec10223e3eb4fa8df411ddd5cd8f": "/32.d94a41685154f34ec771.chunk.js",
    "4729efbf5fa29a8fc8f5aa272f96c26650ca951c": "/33.8d706d0547712b4617fa.chunk.js",
    "3aec214dd95728bdb59e5efafbae1f4700a90450": "/34.3fb2f09843a6952799f5.chunk.js",
    "a6993e62e07fbf19f4106409117d1063f0c6a58d": "/35.c64ec26b8c18d47f6459.chunk.js",
    "7541d3f95f0faa632ce0bcf1d1d1540518269ec4": "/36.89a3522be118282c11da.chunk.js",
    "62c43e8028726d9210c99b7de0e565235c1e27ca": "/37.6f9b176a3421e302eaca.chunk.js",
    "b4033d6cbc72920692bd2764539da0815887814d": "/38.e7039407436bc19f2e1e.chunk.js",
    "6f316b98b3ed6b435b3dfb81317b93aea07a8f53": "/39.2b697c6d7aeb4f73f4a9.chunk.js",
    "c2ebfe38d6c5f0bf0a61470f8071a2cc80e71e70": "/40.b99752e481cecf87f579.chunk.js",
    "edcdfe04520eac526a1f7594bf8e917f571611c3": "/41.0cf410fee57f643cf1c1.chunk.js",
    "440a2b73143ea5f77e131f96ff1d5d13db648e14": "/42.0e9e66baf8e6f82ebf6e.chunk.js",
    "c21eafd907e0d81b7a991074337d8d389bd09277": "/43.3e9c6b13edca3a1868c7.chunk.js",
    "0267ca9086ccfc15a29c5c3321ebf9fd45234a54": "/44.2516a3c0e7e15719d956.chunk.js",
    "e6d833b07e32a1624e94f39c8ccb638ef6f6d328": "/45.4cf458c298cfebc2c0b8.chunk.js",
    "7d2b60dfa45beb6e7eff87075156b703fe7c2114": "/46.cc5493e2694e74ad7747.chunk.js",
    "e1c74fd5e1a707bf77edb57e320071b2805666bd": "/47.b7a12c8b5f405466ee08.chunk.js",
    "7641a55d18a90c673b170a16143006cce494d187": "/48.cd06be3c10ca1f6ceaa0.chunk.js",
    "547faacb1f3f859a900eb904fc468c803a25fe3f": "/49.c405b5c69cce9efe901f.chunk.js",
    "f725c5cbd7b571cae1b1cb6a1b487032717aa610": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "2/20/2021, 1:47:39 AM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });