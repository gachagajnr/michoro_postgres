var __wpo = {
  "assets": {
    "main": [
      "/8e0df7a5dc00616d7e23f5e674bac4a7.png",
      "/favicon.ico",
      "/c21b5e5b3af3e61e9704507be21ca076.png",
      "/runtime.6a578ac141dc1f3168ed.js",
      "/"
    ],
    "additional": [
      "/npm.antd.a4e92bae4dd5881bd8c9.chunk.js",
      "/npm.material-ui.c03484e09d8cf9ef10de.chunk.js",
      "/npm.ant-design.025a053d2aa82cf4524a.chunk.js",
      "/npm.rc-util.aa12f13afe144d47fa80.chunk.js",
      "/4.c2c3966a9b1908f9308d.chunk.js",
      "/npm.decode-uri-component.402b25efe3a15483d348.chunk.js",
      "/npm.formik-antd.bc30835c6465d240aa5e.chunk.js",
      "/npm.intl.d600b589a6d8230522c5.chunk.js",
      "/npm.query-string.463b50c01b30d9dd4a6d.chunk.js",
      "/npm.rc-tabs.df88f29dd48b27c16f34.chunk.js",
      "/10.a037758ad24bfc924ed3.chunk.js",
      "/11.06684a02e527492dc032.chunk.js",
      "/main.b1738a35e795e076cdaa.chunk.js",
      "/npm.core-js.ea40b0d4d0eef1348d9f.chunk.js",
      "/npm.lodash.fb0ee368e79959c7c26b.chunk.js",
      "/npm.lodash-es.1c0ef662202de5f8d81b.chunk.js",
      "/npm.rc-dialog.90fa9e4025b4dcad0089.chunk.js",
      "/npm.react-app-polyfill.2cd579010dee4d1c5bf4.chunk.js",
      "/npm.split-on-first.02d81ed10c34e784df25.chunk.js",
      "/20.bcaeafcc77768c4da5e0.chunk.js",
      "/21.9b789dd4ea745313a49f.chunk.js",
      "/22.eaeeec3d80661399a293.chunk.js",
      "/23.873c21351d13da255d11.chunk.js",
      "/24.1503916fea7f8bebc373.chunk.js",
      "/25.40e54701cc5a307f6b60.chunk.js",
      "/26.003f41b3e92e82e1ab88.chunk.js",
      "/27.053efbca5680b384be99.chunk.js",
      "/28.bc8e3804466ca4283d49.chunk.js",
      "/29.d89f7b5345b2a82ec88b.chunk.js",
      "/30.80b1b74a8fceb17be201.chunk.js",
      "/31.4dc83e28d4e19eb54e3e.chunk.js",
      "/32.2e18dc9fb4d86f2f7e6f.chunk.js",
      "/33.7c24ff57b067d5cf7a29.chunk.js",
      "/34.6c7c8a22d20d48e78bb6.chunk.js",
      "/35.83acc6d127bdb3e78ecc.chunk.js",
      "/36.43e88f9a05174b110313.chunk.js",
      "/37.f36a2647104bc1a1aab2.chunk.js",
      "/38.f3ecc215e706e33bad22.chunk.js",
      "/39.72ce174c80bfa5313f34.chunk.js",
      "/40.8004acb052c87e271f3d.chunk.js",
      "/41.113a87705e1f5dbfbc94.chunk.js",
      "/42.9ac9ace6b85e04a78737.chunk.js",
      "/43.94d9d5ad783112468761.chunk.js",
      "/44.3f215450e8b1514b019e.chunk.js",
      "/45.8898f8c0c8296153ddda.chunk.js",
      "/46.fc6d86d8e7e4b05e7f37.chunk.js",
      "/47.2e51262555b3fb1afba5.chunk.js",
      "/48.d6dfc12a231826f36c11.chunk.js",
      "/49.66430522a810ca6d234e.chunk.js",
      "/50.483f2ae9b2474805f88b.chunk.js",
      "/51.ce950752b79579f60862.chunk.js",
      "/52.4884b73ce1143c775d09.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "8a6cf0acb01232499fd518412913f049684c5f42": "/8e0df7a5dc00616d7e23f5e674bac4a7.png",
    "1133c693aa0420b4fb7d0f64bb6efe42531a8b6a": "/favicon.ico",
    "c8d13970f2fac0b22bb27417cc0db56cec531dd9": "/c21b5e5b3af3e61e9704507be21ca076.png",
    "37d7f13eff647648601ca44efbe2e90ea36097dc": "/npm.antd.a4e92bae4dd5881bd8c9.chunk.js",
    "81a36225139d140d019c5324d86efa43bf73c2e7": "/npm.material-ui.c03484e09d8cf9ef10de.chunk.js",
    "4c5c318f8466715b1dfa5f0f1a2d8e3e12867cef": "/npm.ant-design.025a053d2aa82cf4524a.chunk.js",
    "ae096a9121c9f1365c57f84034a5adcd8f342e77": "/npm.rc-util.aa12f13afe144d47fa80.chunk.js",
    "38dbd53ca267d1acbf3cb7bf94cfa1d7b07406e0": "/4.c2c3966a9b1908f9308d.chunk.js",
    "b3f8ca5314b6d0d10ad7621c08ab2e00cf988ed8": "/npm.decode-uri-component.402b25efe3a15483d348.chunk.js",
    "28f72e97a271c3f4595068aed6bab1068b42d05b": "/npm.formik-antd.bc30835c6465d240aa5e.chunk.js",
    "24421e55628b8f84ea6ebe24e32164a4578d473a": "/npm.intl.d600b589a6d8230522c5.chunk.js",
    "3642c0369f7b3a5edd4ed3cf610c2ef6ae5a1084": "/npm.query-string.463b50c01b30d9dd4a6d.chunk.js",
    "4d4b58d4073dfd06485b6fe427f643a1ae30b0aa": "/npm.rc-tabs.df88f29dd48b27c16f34.chunk.js",
    "57964f42e382046843fba92cc2a2e897bfafaeb3": "/10.a037758ad24bfc924ed3.chunk.js",
    "f56951736eff3cf51f7612d6510a7df7eb8ec8f2": "/11.06684a02e527492dc032.chunk.js",
    "1fadf52515cd686662c45980f222c8070494e503": "/main.b1738a35e795e076cdaa.chunk.js",
    "d625b454981cbdb57cf0b0c70ed4b532d4acd991": "/npm.core-js.ea40b0d4d0eef1348d9f.chunk.js",
    "96da5ca69b69a651661919c065c8b417331fe12c": "/npm.lodash.fb0ee368e79959c7c26b.chunk.js",
    "a519e8331e7debe4747879ee8cbb75b86bd77dd3": "/npm.lodash-es.1c0ef662202de5f8d81b.chunk.js",
    "117227f9f83dc23d6e6388118633ba8a49531850": "/npm.rc-dialog.90fa9e4025b4dcad0089.chunk.js",
    "17b47b7761e807cce3d7bcb2c78df09aa9599c15": "/npm.react-app-polyfill.2cd579010dee4d1c5bf4.chunk.js",
    "4ae2fe576347f00e00d806c10a1d106f023c92e3": "/npm.split-on-first.02d81ed10c34e784df25.chunk.js",
    "ae1dc46cc0da1cabead6a27a3d0dc5f3621c4514": "/runtime.6a578ac141dc1f3168ed.js",
    "19db63aa7260175c5e207e4c584813cda945b297": "/20.bcaeafcc77768c4da5e0.chunk.js",
    "8cb5aacfee9373fd9a02c37a1e740185cbf28bea": "/21.9b789dd4ea745313a49f.chunk.js",
    "a43fe66858657ba3efd8c3289521cd689378d1c5": "/22.eaeeec3d80661399a293.chunk.js",
    "b0ef496dfa696829a6be31d5bb53260d3cab53c9": "/23.873c21351d13da255d11.chunk.js",
    "35fbb9ef2c1d5c71efde0c94847f0299bbb45643": "/24.1503916fea7f8bebc373.chunk.js",
    "a5127b8ec22e3d0fe49b8e15b8331a1c4eb6bc6c": "/25.40e54701cc5a307f6b60.chunk.js",
    "e9ca3046fbfaf3b601f97975dc57dc9ecf494b25": "/26.003f41b3e92e82e1ab88.chunk.js",
    "9c0269530252ed648763ad45b16b58980a4e3794": "/27.053efbca5680b384be99.chunk.js",
    "da46e365d03833cbaf4048ea61318c0456648993": "/28.bc8e3804466ca4283d49.chunk.js",
    "ba0305554a08dd4b7f3cacb9af64e63098ad9433": "/29.d89f7b5345b2a82ec88b.chunk.js",
    "8e701012a5306a3e7f6cd1f866ea87dab829b156": "/30.80b1b74a8fceb17be201.chunk.js",
    "11da6c35c6ecbe0480e719d6fbfb2b3909fb4fe2": "/31.4dc83e28d4e19eb54e3e.chunk.js",
    "50894c1952e76c03c9d58b8cd13da4ba1396d6a9": "/32.2e18dc9fb4d86f2f7e6f.chunk.js",
    "f1da069eac3431739b83668684882c8447c2030b": "/33.7c24ff57b067d5cf7a29.chunk.js",
    "db0f1773ca6b8f785aeffb5ed40f62634925cbe1": "/34.6c7c8a22d20d48e78bb6.chunk.js",
    "44b8f72604016c058f78192facf21b957b2c6993": "/35.83acc6d127bdb3e78ecc.chunk.js",
    "9baba027df8c6e3f4d8d4224b1a87b4aac4b31d2": "/36.43e88f9a05174b110313.chunk.js",
    "509787faba208d1935def1eb584e557cd055f3e6": "/37.f36a2647104bc1a1aab2.chunk.js",
    "49ebce57123183cbb57f8a230b87a38fbe70e9d5": "/38.f3ecc215e706e33bad22.chunk.js",
    "45260c04dec86e59ea05ead3fa2d01f549a21f9f": "/39.72ce174c80bfa5313f34.chunk.js",
    "86b75dcf2db5780dee4b1ecfea6d675cbdc4030a": "/40.8004acb052c87e271f3d.chunk.js",
    "e8c1742428b79009fd6f22423028fc37ab7aa48d": "/41.113a87705e1f5dbfbc94.chunk.js",
    "d19f4aba4c969f1dba1951cd4a17fb71326e27ea": "/42.9ac9ace6b85e04a78737.chunk.js",
    "be3c55d4d87bd6aea978913557689e9ff39a3f42": "/43.94d9d5ad783112468761.chunk.js",
    "ec83761a2063f80b4cc572fe182cdc4f6fe4e890": "/44.3f215450e8b1514b019e.chunk.js",
    "4543fa53104d045b2eed21b4ac559ce46bd1bc40": "/45.8898f8c0c8296153ddda.chunk.js",
    "623c117722cef279ce7e907c71c07b71032dd506": "/46.fc6d86d8e7e4b05e7f37.chunk.js",
    "b363a39dd27bab6d147ac3e74fe8047085f41180": "/47.2e51262555b3fb1afba5.chunk.js",
    "5b2038b35e13877a4065e6905b121f58619b722f": "/48.d6dfc12a231826f36c11.chunk.js",
    "bb5ed89adbe94fb7725c8148b7f4dff0ded8d8db": "/49.66430522a810ca6d234e.chunk.js",
    "9a14016f1405011b4314d339fd64bbccdb725738": "/50.483f2ae9b2474805f88b.chunk.js",
    "01b65c87435337d0f125a1253c31deead37dfd6b": "/51.ce950752b79579f60862.chunk.js",
    "f36decd25a60c9b8e8c7d0f5951525b85cc3a3bf": "/52.4884b73ce1143c775d09.chunk.js",
    "1b8d7e128a3f221c4f216213f0d564ba016b7f25": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "21/04/2021, 08:45:47",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });