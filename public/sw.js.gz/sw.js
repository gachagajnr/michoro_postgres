var __wpo = {
  "assets": {
    "main": [
      "/8e0df7a5dc00616d7e23f5e674bac4a7.png",
      "/favicon.ico",
      "/24d3eea8c5cf7d34ed7aa26e5652706b.png",
      "/runtime.01f766733b7921da712f.js",
      "/"
    ],
    "additional": [
      "/npm.antd.8568cd5191a1a3956d87.chunk.js",
      "/npm.material-ui.83f84a875ef20693ce08.chunk.js",
      "/npm.decode-uri-component.30972a13f1b4f5968444.chunk.js",
      "/npm.query-string.20632a8bad0db0b339b4.chunk.js",
      "/npm.split-on-first.ebb5153ed4aa58c9109b.chunk.js",
      "/npm.strict-uri-encode.5ed10ca36d079d3f21dc.chunk.js",
      "/npm.ant-design.4ba9b676bf5b1e9c7533.chunk.js",
      "/npm.rc-util.047f583b1ab13e5fb8bc.chunk.js",
      "/8.2569989b84a673a741ab.chunk.js",
      "/npm.formik-antd.bcea09a4a12ae2fb2aff.chunk.js",
      "/npm.intl.4c694859552ab6363c76.chunk.js",
      "/npm.rc-tabs.fbb517186e3ff799364e.chunk.js",
      "/12.4d1d29f457d372b283ef.chunk.js",
      "/13.d5c205cea824c657785a.chunk.js",
      "/main.098adeb6e9bb18bbbff0.chunk.js",
      "/npm.core-js.76c4e2c0c40937c12047.chunk.js",
      "/npm.lodash.aa18a2f189b18eb13089.chunk.js",
      "/npm.lodash-es.d097ededed7ec42cc223.chunk.js",
      "/npm.rc-dialog.6bb6784897030e0992a8.chunk.js",
      "/npm.react-app-polyfill.ec93dddd61aab8f3298f.chunk.js",
      "/21.c21ec297aaf1b099b96b.chunk.js",
      "/22.157356f44b12614adc03.chunk.js",
      "/23.649b2727ab007f766c39.chunk.js",
      "/24.5aff154c3f0b7ff97b5e.chunk.js",
      "/25.1a832087a8bdb4fd3a9d.chunk.js",
      "/26.f68613406c5a04be093d.chunk.js",
      "/27.f5bf1b286dd6c04e0b70.chunk.js",
      "/28.9077526e7cecf70bd50c.chunk.js",
      "/29.a245e53d33eb3f04aa2c.chunk.js",
      "/30.2b7d9ce11e1cb2494775.chunk.js",
      "/31.45b67b41c52399dd2fd9.chunk.js",
      "/32.572ab7d44e39e2b5baf7.chunk.js",
      "/33.bc544ec908ba7864af58.chunk.js",
      "/34.fca14dd39239cc66e5e5.chunk.js",
      "/35.ea908fb2de6aaa82ba6f.chunk.js",
      "/36.ba55dd248d2616d6948c.chunk.js",
      "/37.cf46cab96faf64246574.chunk.js",
      "/38.89f80fbcad37dc1c3ccb.chunk.js",
      "/39.796f5be4dd2c409062df.chunk.js",
      "/40.73a65603a1c5d00cf7bf.chunk.js",
      "/41.ce44fc5965c53754b469.chunk.js",
      "/42.9ac9ace6b85e04a78737.chunk.js",
      "/43.d3ee82b3f073a5087261.chunk.js",
      "/44.602cecc4cf6e29457cf9.chunk.js",
      "/45.54ce623365d1418d8699.chunk.js",
      "/46.ab0b335d419c7928f194.chunk.js",
      "/47.3c687c7202b0bed95c60.chunk.js",
      "/48.73f14f4972413a4f0411.chunk.js",
      "/49.fd4dea4f33279c8e5712.chunk.js",
      "/50.4dbdd5565a30c4dddce2.chunk.js",
      "/51.931db1a9efff5d0e121c.chunk.js",
      "/52.50c8f5df6429a2a021af.chunk.js",
      "/53.b99272bdd1dc42c62a33.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "8a6cf0acb01232499fd518412913f049684c5f42": "/8e0df7a5dc00616d7e23f5e674bac4a7.png",
    "1133c693aa0420b4fb7d0f64bb6efe42531a8b6a": "/favicon.ico",
    "f15d14e696bf0bc87792cb0114fc36ae59daac0e": "/24d3eea8c5cf7d34ed7aa26e5652706b.png",
    "cf954b36d7c0acc6ccc1be313b478217fcd13e71": "/npm.antd.8568cd5191a1a3956d87.chunk.js",
    "5e48b51f29ce2bd1a319be55961cceb4c288420b": "/npm.material-ui.83f84a875ef20693ce08.chunk.js",
    "0ad7e5579596546505bff19d0270d674650b2ba4": "/npm.decode-uri-component.30972a13f1b4f5968444.chunk.js",
    "c6359231e1e4e1496c2f296b07b8bce5e1bb7c0d": "/npm.query-string.20632a8bad0db0b339b4.chunk.js",
    "72724efc8508761960243f292769ff399c25b71e": "/npm.split-on-first.ebb5153ed4aa58c9109b.chunk.js",
    "c7c0611abbb61b57e8ae51366d21fa0a68e67078": "/npm.strict-uri-encode.5ed10ca36d079d3f21dc.chunk.js",
    "8623c3cc3025bb8256d7af1641b8c7af4172dfb8": "/npm.ant-design.4ba9b676bf5b1e9c7533.chunk.js",
    "b916d76c6e0a577efb7217c8a1637d1809c3a510": "/npm.rc-util.047f583b1ab13e5fb8bc.chunk.js",
    "9a1e077a4f3eec3d0dee8f36f7390e52429396e0": "/8.2569989b84a673a741ab.chunk.js",
    "7584c6f32a61f3675dc5e4b41b4978e168c7670e": "/npm.formik-antd.bcea09a4a12ae2fb2aff.chunk.js",
    "0872d3239bc9bbcf872bdbe0f4ff415281914676": "/npm.intl.4c694859552ab6363c76.chunk.js",
    "b3f918c36e88b90d4895d526add753196ebd7657": "/npm.rc-tabs.fbb517186e3ff799364e.chunk.js",
    "f9046d47d55672401f06a66d8846d814813e6729": "/12.4d1d29f457d372b283ef.chunk.js",
    "a491942135573a7b68eafe45e73676523988f86c": "/13.d5c205cea824c657785a.chunk.js",
    "036568903ccac99ca1c07b9c813955da9d1c6063": "/main.098adeb6e9bb18bbbff0.chunk.js",
    "d610c585c5102b376d4ce78c2b6dfe02bfe983b4": "/npm.core-js.76c4e2c0c40937c12047.chunk.js",
    "171809c3780e2112943c79fe1f412099a336fd27": "/npm.lodash.aa18a2f189b18eb13089.chunk.js",
    "66d45f04f86332604b2861f3d4510b574f29d2a0": "/npm.lodash-es.d097ededed7ec42cc223.chunk.js",
    "c22afbcb946aded08699045777d280954dde7fbb": "/npm.rc-dialog.6bb6784897030e0992a8.chunk.js",
    "3a7c23afe21870f6cf0d25f3fd7b9f6244d2c780": "/npm.react-app-polyfill.ec93dddd61aab8f3298f.chunk.js",
    "365f141ed7337bf21aa8ede7223df382f549bc12": "/runtime.01f766733b7921da712f.js",
    "a781439d3ab637a34efb9ea4d84c2ed57a385fff": "/21.c21ec297aaf1b099b96b.chunk.js",
    "547077a2e80ee78ddb75bcf7814ad17f7a7acf9b": "/22.157356f44b12614adc03.chunk.js",
    "60750e48f1930342a71561eaf5e33242ed067817": "/23.649b2727ab007f766c39.chunk.js",
    "8d8d8e50b43de2d798bab0470885221ca8b67a47": "/24.5aff154c3f0b7ff97b5e.chunk.js",
    "5253a1d5c3d132b71ea4469db4258ab53f7d7aa8": "/25.1a832087a8bdb4fd3a9d.chunk.js",
    "de0e514d9a9407aa19a2fe2e557d55c9942b1eb1": "/26.f68613406c5a04be093d.chunk.js",
    "ed934e0883c45a484a746c15034de01ae7d7163e": "/27.f5bf1b286dd6c04e0b70.chunk.js",
    "d6a0798884c8d0446ff16faa3b589d5f0f6b3e52": "/28.9077526e7cecf70bd50c.chunk.js",
    "e7ed40b5e6f22510a60e7dda603deecba29cda00": "/29.a245e53d33eb3f04aa2c.chunk.js",
    "a6beaa542447a36a3bb4d6ae6552f5cfa8bc9a54": "/30.2b7d9ce11e1cb2494775.chunk.js",
    "e81cab56c153bc39742d42560bd262722cabd468": "/31.45b67b41c52399dd2fd9.chunk.js",
    "ffc3bcd81aa6b1ffcea1a3bba6bd2ffc396aa7fa": "/32.572ab7d44e39e2b5baf7.chunk.js",
    "2486de2962816ac06ed4040ce90ff6f22f10b936": "/33.bc544ec908ba7864af58.chunk.js",
    "7ebfd5a3f39a9f1dd4fe37a665f61ff30791609d": "/34.fca14dd39239cc66e5e5.chunk.js",
    "6a33b70c62b11977f033278aaea2e293dc2866fe": "/35.ea908fb2de6aaa82ba6f.chunk.js",
    "94af64b80ccbdad7c156343892369cbcffe2ab05": "/36.ba55dd248d2616d6948c.chunk.js",
    "24026bdb9480737b31d2a68d3533249ecadf4df0": "/37.cf46cab96faf64246574.chunk.js",
    "4b8352485f6cf8dca6956e42128e960e8d278ec7": "/38.89f80fbcad37dc1c3ccb.chunk.js",
    "753b98bb300c4cd83b12d396ca60bf3899980d8a": "/39.796f5be4dd2c409062df.chunk.js",
    "cbae0011d9d8678a8f1219b2fa78891db3ad789b": "/40.73a65603a1c5d00cf7bf.chunk.js",
    "81a351aae884e3587004a2b45632a4a30b0408cd": "/41.ce44fc5965c53754b469.chunk.js",
    "d19f4aba4c969f1dba1951cd4a17fb71326e27ea": "/42.9ac9ace6b85e04a78737.chunk.js",
    "ec2812875e8c6690dd2b4ab171c4ea90299b97e5": "/43.d3ee82b3f073a5087261.chunk.js",
    "0d57d45fa5144aad6f14fa9dd5683c557917a25c": "/44.602cecc4cf6e29457cf9.chunk.js",
    "12cc003ff2cc4ebdc2c594356abbaf64fadb3fd2": "/45.54ce623365d1418d8699.chunk.js",
    "a78893127fe92533256a963ab217be77a30f1952": "/46.ab0b335d419c7928f194.chunk.js",
    "347ede28dd1c1d961e49fcb5f7ccf656bab5002b": "/47.3c687c7202b0bed95c60.chunk.js",
    "d11c4024c82ef6acfc168cf772eb835c4ceab356": "/48.73f14f4972413a4f0411.chunk.js",
    "85b65e9ece2e1b9b36f7e0c1251937d31d63eb68": "/49.fd4dea4f33279c8e5712.chunk.js",
    "49938b9bf0a75a3ef11e64b805c414ae190a7a24": "/50.4dbdd5565a30c4dddce2.chunk.js",
    "01e2d074d5733f9566d58516af453616b2afbc9f": "/51.931db1a9efff5d0e121c.chunk.js",
    "56c89f02cef2284981db022d65b66fb1056e01a2": "/52.50c8f5df6429a2a021af.chunk.js",
    "20c0ead0519bddc364069b06dd57edd4bc5c843d": "/53.b99272bdd1dc42c62a33.chunk.js",
    "5b5864ff386d14d967b4a1b5debb194672debb0c": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "4/15/2021, 11:43:56 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });